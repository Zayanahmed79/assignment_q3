# streamlit python projects

[Project 1: Growth Mindset](https://growth-mindset-srk.streamlit.app/)

[Project 2: Data Sweeper](https://data-sweeper-srk.streamlit.app/)

[Project 3: Unit Convertor](https://unit-convertor-srk.streamlit.app/)

[Project 4: Password Strength Meter](https://password-strength-meter-srk.streamlit.app/)
